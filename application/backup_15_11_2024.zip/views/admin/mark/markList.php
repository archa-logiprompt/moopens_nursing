<style type="text/css">
@media print {

    .no-print,
    .no-print * {
        display: none !important;
    }
}

.print,
.print * {
    display: none;
}
th, td {
    white-space: normal;
    overflow: hidden; /* Hide overflowing content */
    text-overflow: ellipsis; /*  /* Allow text to wrap */
    font-size: 15px;
    }

.tabledesign td {
        width: 125px;
        padding: 2px;
}
</style>

<div class="content-wrapper" style="min-height: 946px;">
    <section class="content-header">
        <h1>
            <i class="fa fa-map-o"></i> <?php echo $this->lang->line('examinations'); ?>
            <small><?php echo $this->lang->line('student_fee1'); ?></small>
        </h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-search"></i>
                            <?php echo $this->lang->line('select_criteria'); ?></h3>
                        <div class="box-tools pull-right">
                            <?php if ($this->rbac->hasPrivilege('marks_register', 'can_add')) { ?>
                            <a href="<?php echo base_url(); ?>admin/mark/create" class="btn btn-primary btn-sm"
                                data-toggle="tooltip" title="<?php echo $this->lang->line('add'); ?>">
                                <i class="fa fa-plus"></i> <?php echo $this->lang->line('add'); ?>
                            </a>
                            <?php } ?>
                        </div>
                    </div>
                    <form action="<?php echo site_url('admin/mark') ?>" method="post" accept-charset="utf-8"
                        id="schedule-form">
                        <div class="box-body">
                            <div class="row">
                                <input type="hidden" name="save_exam" value="search">
                                <?php echo $this->customlib->getCSRF(); ?>
                                <!-- /.col -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label
                                            for="exampleInputEmail1"><?php echo $this->lang->line('class'); ?></label>
                                        <select id="class_id" name="class_id" class="form-control">
                                            <option value=""><?php echo $this->lang->line('select'); ?></option>
                                            <?php
                                            foreach ($classlist as $class) {
                                                ?>
                                            <option value="<?php echo $class['id'] ?>" <?php
                                                if ($class_id == $class['id']) {
                                                    echo "selected =selected";
                                                }
                                                ?>><?php echo $class['class'] ?></option>

                                            <?php
                                                $count++;
                                            }
                                            ?>
                                        </select>
                                        <span class="text-danger"><?php echo form_error('class_id'); ?></span>
                                    </div>
                                </div><!-- /.col -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label
                                            for="exampleInputEmail1"><?php echo $this->lang->line('section'); ?></label>
                                        <select id="section_id" name="section_id" class="form-control">
                                            <option value=""><?php echo $this->lang->line('select'); ?></option>
                                        </select>
                                        <span class="text-danger"><?php echo form_error('section_id'); ?></span>
                                    </div>
                                </div>


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label
                                            for="exampleInputEmail1"><?php echo $this->lang->line('exam_name'); ?></label>

                                        <select autofocus="" id="exam_id" name="exam_id" class="form-control">
                                            <option value=""><?php echo $this->lang->line('select'); ?></option>

                                        </select>
                                        <span class="text-danger"><?php echo form_error('exam_id'); ?></span>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1"><?php echo $this->lang->line('subject'); ?>
                                            <?php echo $this->lang->line('type'); ?> </label>

                                        <select autofocus="" id="sub_type" name="sub_type" class="form-control">
                                            <option value=""><?php echo $this->lang->line('select'); ?></option>
                                            <option <?php if($sub_type=='Theory') { echo 'selected';} ?> value="Theory">
                                                Theory</option>
                                            <option <?php if($sub_type=='Practical') { echo  'selected';} ?>
                                                value="Practical">Practical</option>
                                            <option <?php if($sub_type=='Viva') { echo 'selected';} ?> value="Viva">Viva
                                            </option>
                                        </select>
                                        <span class="text-danger"><?php echo form_error('sub_type'); ?></span>
                                    </div>

                                </div>




                                <!-- /.col -->
                            </div><!-- /.row -->
                        </div><!-- /.box-body -->
                    </form>
                </div>
                <?php
				
                if (isset($examSchedule['status'])) {
                    ?>

                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">
                            <i class="fa fa-list"></i> <?php echo $this->lang->line('marks_register'); ?>
                        </h3>
                        <button type="button" style="margin-right: 10px;margin-top: 10px;" name="search"
                        id="collection_print" value=""
                        class="btn btn-sm btn-primary login-submit-cs fa fa-print pull-right">
                        <?php echo $this->lang->line('print'); ?></button>
                    </div>
                    
                    
                    <div class="box-body">
                        <?php
                            if ($examSchedule['status'] == "yes") {
                                ?>

                        <form role="form" id="" class="" method="post"
                            action="<?php echo site_url('admin/mark/create') ?>">
                            <?php echo $this->customlib->getCSRF(); ?>
                            <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                            <input type="hidden" name="section_id" value="<?php echo $section_id; ?>">
                            <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                            <div class="table-responsive">
                                <div class="download_label">
                                    <?php echo $this->Setting_model->getCurrentSchoolName();?></br>
                                    <?php echo $this->lang->line('marks_register'); ?></div>
                                    <div class="box-body" id="printcontent">
                                <!-- <table class="table table-striped table-bordered table-hover", border="1"> -->
                                    
                                <table  class="tabledesign" style="width:100%;" border="1">
                                    <thead>
                                        <tr>
                                            <th>
                                                <?php echo $this->lang->line('admission_no'); ?>
                                            </th>
                                            <th>
                                                <?php echo $this->lang->line('roll_no'); ?>
                                            </th>
                                            <th>
                                                <?php echo $this->lang->line('student'); ?>
                                            </th>
                                          


                                            <?php
                                                    $s = 0;
                                                    if ($examSchedule['status'] == "yes") {
													
                                                        foreach ($examSchedule['result'] as $key => $st) {
                                                            if ($s == 0) {
                                                                foreach ($st['exam_array'] as $key => $exam_schedule) { $teacher=getteacheranme($exam_schedule['teacher_id']);
                                                                    ?>
                                            <th>
                                                <?php
                                                                        echo $exam_schedule['exam_name'] . "<br/> (" . substr($exam_schedule['exam_type'], 0, 2). ": " . $exam_schedule['passing_marks'] . "/" . $exam_schedule['full_marks'] . ")"; 
					if(!empty($teacher)){ $tc='';
						foreach ($teacher as $key => $tech)
								{	 											
									$tc.=$tech->name.',' ;
						 		}
							} 
							 echo "<br/>(".$tc.")"?>;
                                            </th>
                                            <?php
                                                                }
                                                            }
                                                            $s++;
                                                        }
                                                    } else {
                                                        ?>

                                            <?php
                                                    }
                                                    ?>
                                            <th><?php echo $this->lang->line('grand_total'); ?></th>
                                            <th><?php echo $this->lang->line('percent') . ' (%)'; ?></th>
                                            <th><?php echo "Over all Result" ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                                $s = 0;
                                                foreach ($examSchedule['result'] as $key => $student) {
													
                                                    ?>
                                        <input type="hidden" name="student[]"
                                            value="<?php echo $student['student_id'] ?>">

                                        <?php
                                                if (!empty($student['exam_array'])) {
                                                    if ($s == 0) {
                                                        foreach ($student['exam_array'] as $key => $exam_schedule) {
                                                            ?>
                                        <input type="hidden" name="exam_schedule[]"
                                            value="<?php echo $exam_schedule['exam_schedule_id'] ?>">
                                        <?php
                                                        }
                                                    }
                                                } else {
                                                    ?>

                                        <?php
                                                }
                                                $s++;
                                            }
                                            ?>
                                        <?php
                                            foreach ($examSchedule['result'] as $key => $student) {
												
                                                $total_marks = 0;
                                                $obtain_marks = "0";
                                                $result = "Pass";
                                                ?>
                                        <tr>
                                            <td>
                                                <?php echo $student['admission_no'] ?>
                                            </td>
                                            <td>
                                                <?php echo $student['roll_no'] ?>
                                            </td>
                                            <td>
                                                <?php echo $student['firstname'] . " " . $student['lastname']; ?>
                                            </td>
                                           
                                            <?php
                                                    if (!empty($student['exam_array'])) {
                                                        count($student['exam_array']);
                                                        $s = 0;

                                                        
                                                        $subject_ids= [];
                                                        foreach ($student['exam_array'] as $key => $exam_schedule) {
                                                            
                                                            $subject_ids[]=$exam_schedule['teacher_subject_id'];
                                                            $total_marks = (int) $total_marks + (int) $exam_schedule['full_marks'];
                                                            ?>
                                            <td>
                                            <?php
                                                if (!isset($exam_schedule['attendence'])) {
                                                    echo "N/A";
                                                    $result = "N/A";
                                                } else {

                                                    if ($exam_schedule['attendence'] == "pre") {
                                                        
                                                        $passing_marks_student = $exam_schedule['passing_marks'];
                                                         $get_marks_student = $exam_schedule['get_marks'];
                                                         if ($get_marks_student > $passing_marks_student) {
                                                            echo $get_marks_student . "   " . "<span style='color: green;'>(PASSED)</span>";
                                                        } else {
                                                            echo $get_marks_student . "   " . "<span style='color: red;'>(FAILED)</span>";
                                                        }
                                                        if ($result == "Pass") {
                                                            if ($get_marks_student < $passing_marks_student) {
                                                                $result = "Fail";
                                                            }
                                                        }
                                                        $obtain_marks = $obtain_marks + $exam_schedule['get_marks'];
                                                    } else {
                                                        $result = "Fail";
                                                        $s++;
                                                        echo ($exam_schedule['attendence']);
                                                    }
                                                }
                                                ?>
                                            </td>
                                            <?php
                                                        }
                                                        if ($s == count($student['exam_array'])) {
                                                            $obtain_marks = 0;
                                                        }
                                                        ?>
                                            <td> <?php echo $obtain_marks . " /" . $total_marks; ?> </td>
                                            <td> <?php
                                           $per = $obtain_marks * 100 / $total_marks;
                                             echo number_format($per, 2, '.', '');
                                                            ?>

                                            </td>
                                            <th>
                                                <?php
                                                
                                        // to check if combinedsubjects will cover for passing mark

                                        $combinedsubjects = (getcombinedsubjects($subject_ids,$class_id,$section_id)); 

                                        $firstArray =  $student['exam_array'];
                                        $secondArray =  $combinedsubjects;
                                        $filteredArray = array_filter($firstArray, function($item) use ($secondArray) {
                                            foreach ($secondArray as $subject) {
                                                if (in_array($subject['subject1'], [$item['teacher_subject_id']]) || in_array($subject['subject2'], [$item['teacher_subject_id']])) {
                                                    return true;
                                                }
                                            }
                                            return false;
                                        });
                                        
                                       

                                        echo '<br/>';
                                        // echo '<br/>';
 
  

                                        $notcombined = array_filter($student['exam_array'] , function($value) use ($combinedsubjects) {
                                            foreach ($combinedsubjects as $item) {
                                                if ($item["subject1"] === $value['teacher_subject_id'] || $item["subject2"] === $value['teacher_subject_id']) {
                                                    return false;
                                                }
                                            }
                                            return true;
                                        });
                                        
                                        // print_r($notcombined);


                                        $newArray = [];
                                        $arrcount = 0;
                                        $arrindex = 1;
                                        foreach ($filteredArray as $key => $value) {
                                            $newArray[$arrcount][] = $value;
                                           
                                             if($arrindex % 2 == 0){

                                                $arrcount++;
                                              }
                                              $arrindex++;
                                        }

                                        // print_r(array_sum(array_column($newArray[0],'get_marks')));



                                        
                                            if($result=='Fail'){

                                                foreach ($newArray as $key => $filteredArray) {
                                                   
                                                    $combinedmark = $filteredArray[0]['get_marks']+$filteredArray[1]['get_marks'];
                                                }

                                                


                                                $combinedmark>=$filteredArray[0]['passing_marks']?$result='Pass':$result='Fail';

                                            }


                                            foreach ($notcombined as $key => $value) {
                                             
                                                if($value['get_marks'] < $value['passing_marks']){
                                                    $result='Fail';
                                                }

                                            }


                                                            if ($result == "Pass") {

                                                                echo "<label class='label label-success'>";
                                                            } else {

                                                                echo "<label class='label label-danger'>";
                                                            }
                                                            echo $result;
                                                            echo "<label/>";
                                                            ?></th>
                                            <?php
                                                    } else {
                                                        ?>

                                            <?php
                                                    }
                                                    ?>

                                        </tr>
                                        <?php
                                            }
                                            ?>

                                    </tbody>
                                </table>
                                </div>
                                </div>
                            </div>
                        </form>
                        <?php
                            } else {
                                ?>
                        <div class="alert alert-info"><?php echo $this->lang->line('no_record_found'); ?></div>
                        <?php
                            }
                            ?>

                    </div>
                    </div>
                    <!---./end box-body--->
                </div>
            </div>
            <!-- right column -->
        </div> <!-- /.row -->
        <?php
        } else {
            
        }
        ?>
    </section><!-- /.content -->
</div>
<script type="text/javascript">
function getSectionByClass(class_id, section_id) {
    if (class_id != "" && section_id != "") {
        $('#section_id').html("");
        var base_url = '<?php echo base_url() ?>';
        var div_data = '<option value=""><?php echo $this->lang->line('select'); ?></option>';
        $.ajax({
            type: "GET",
            url: base_url + "sections/getByClass",
            data: {
                'class_id': class_id
            },
            dataType: "json",
            success: function(data) {
                $.each(data, function(i, obj) {
                    var sel = "";
                    if (section_id == obj.section_id) {
                        sel = "selected";
                    }
                    div_data += "<option value=" + obj.section_id + " " + sel + ">" + obj.section +
                        "</option>";
                });
                $('#section_id').append(div_data);
            }
        });
    }
}




function getexamtype(exam_id, class_id, section_id) {
    if (exam_id != "") {
        $('#exam_id').html("");

        var base_url = '<?php echo base_url() ?>';
        var div_data = '<option value=""><?php echo $this->lang->line('select'); ?></option>';

        $.ajax({
            type: "POST",
            url: base_url + "admin/exam/get_examtype",
            data: {
                'class_id': class_id,
                'section_id': section_id
            },
            dataType: "json",
            success: function(data) {


                $.each(data, function(i, obj) {
                    var sel = "";
                    if (exam_id == obj.id) {
                        sel = "selected";
                    }

                    div_data += "<option value=" + obj.id + " " + sel + ">" + obj.name +
                    "</option>";

                });

                $('#exam_id').append(div_data);
            }
        });
    }
}







$(document).ready(function() {
    $(document).on('change', '#class_id', function(e) {
        $('#section_id').html("");
        var class_id = $(this).val();
        var base_url = '<?php echo base_url() ?>';
        var div_data = '<option value=""><?php echo $this->lang->line('select'); ?></option>';
        $.ajax({
            type: "GET",
            url: base_url + "sections/getByClass",
            data: {
                'class_id': class_id
            },
            dataType: "json",
            success: function(data) {
                $.each(data, function(i, obj) {
                    div_data += "<option value=" + obj.section_id + ">" + obj
                        .section + "</option>";
                });
                $('#section_id').append(div_data);
            }
        });
    });
    var class_id = $('#class_id').val();
    var section_id = '<?php echo set_value('section_id') ?>';
    var exam_id = '<?php echo $exam_id ?>';
    getSectionByClass(class_id, section_id);
    getexamtype(exam_id, class_id, section_id);

    $(document).on('change', '#feecategory_id', function(e) {
        $('#feetype_id').html("");
        var feecategory_id = $(this).val();
        var base_url = '<?php echo base_url() ?>';
        var div_data = '<option value=""><?php echo $this->lang->line('select'); ?></option>';
        $.ajax({
            type: "GET",
            url: base_url + "feemaster/getByFeecategory",
            data: {
                'feecategory_id': feecategory_id
            },
            dataType: "json",
            success: function(data) {
                $.each(data, function(i, obj) {
                    div_data += "<option value=" + obj.id + ">" + obj.type +
                        "</option>";
                });
                $('#feetype_id').append(div_data);
            }
        });
    });




    $(document).on('change', '#section_id', function(e) {
        $('#exam_id').html("");
        var class_id = $('#class_id').val();
        var section_id = $('#section_id').val();

        var base_url = '<?php echo base_url() ?>';
        var div_data = '<option value=""><?php echo $this->lang->line('select'); ?></option>';
        $.ajax({
            type: "POST",
            url: base_url + "admin/exam/get_examtype",
            data: {
                'class_id': class_id,
                'section_id': section_id
            },
            dataType: "json",
            success: function(data) {

                console.log(data);

                $.each(data, function(i, obj) {

                    div_data += "<option value=" + obj.id + ">" + obj.name +
                        "</option>";

                });

                $('#exam_id').append(div_data);
            }
        });
    });







});
$(document).on('change', '#sub_type', function(e) {
    $("form#schedule-form").submit();
});

$(document).on('click', '#collection_print', function () {
    // Get the class value from the data attribute of the button
    let content = $('#printcontent').html();
    content = btoa(content); 
    // Make an AJAX request to the 'printwithheaderandfooter' method
    $.ajax({
        url: '<?php echo base_url('admin/weeklycalendarnew/printwithheaderandfooter'); ?>',
        method: 'post', 
        data: {
            data: content
        },
         beforeSend: function (xhr) {
        xhr.setRequestHeader('Content-Encoding', 'gzip');
    },
        
        success: function (data) {
            console.log(data)
           data =  data.replace(/['"]+/g, '')
            // Redirect to the generated PDF URL
            window.location.href = "<?php echo base_url() ?>" + data;
        },
        error: function (xhr, status, error) {
            console.error('xhr:', xhr);
            console.error('status:', status);
            console.error('error:', error);
        }
    });
});
</script>