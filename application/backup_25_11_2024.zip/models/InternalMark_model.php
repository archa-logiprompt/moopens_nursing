<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class InternalMark_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }


    public function add($data)
    {
        if (isset($data['id'])) {
            $this->db->where('id', $data['id']);
            $this->db->update('internal_mark_group', $data);
        } else {
            $this->db->insert('internal_mark_group', $data);
            return $this->db->insert_id();
        }
    }

    public function get($id = null)
    {
        $result = $this->db->select("internal_mark_group.*,sections.section,classes.class")->join('classes', 'classes.id=internal_mark_group.class_id')->join('sections', 'sections.id=internal_mark_group.section_id')->get('internal_mark_group')->result_array();
        return $result;
    }

    public function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('internal_mark_group');
    }
}
