<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Internal_mark extends Admin_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('InternalMark_model');
    }

    function index()
    {
        if (!$this->rbac->hasPrivilege('internal_mark_type', 'can_view')) {
            access_denied();
        }
        $this->session->set_userdata('top_menu', 'internal_marks');
        $this->session->set_userdata('sub_menu', 'internal_marks/internal_mark_types');
        $class = $this->class_model->get();
        $data['classlist'] = $class;
        $internalGroup = $this->InternalMark_model->get();
        $data['internalGroup'] = $internalGroup;

        $this->session->set_userdata('top_menu', 'internal_marks');
        $this->session->set_userdata('sub_menu', 'internal_marks/internal_mark_types');

        $this->form_validation->set_rules('type', 'Type', 'trim|required|xss_clean');
        $this->form_validation->set_rules('mark_type', 'Mark Type', 'trim|required|xss_clean');
        $this->form_validation->set_rules('sub_type', 'Sub Type', 'trim|required|xss_clean');
        $this->form_validation->set_rules('class_id', 'Class', 'trim|required|xss_clean');
        $this->form_validation->set_rules('section_id', 'Section', 'trim|required|xss_clean');
        $this->form_validation->set_rules('max_mark', 'Max Mark', 'trim|required|xss_clean');
        $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');


        if ($this->form_validation->run() == FALSE) {
            $this->load->view('layout/header', $data);
            $this->load->view('admin/internal_mark/internal_mark_type', $data);
            $this->load->view('layout/footer', $data);
        } else {
            $insert_array = array(
                'type' => $this->input->post('type'),
                'mark_type' => $this->input->post('mark_type'),
                'sub_type' => $this->input->post('sub_type'),
                'class_id' => $this->input->post('class_id'),
                'section_id' => $this->input->post('section_id'),
                'max_mark' => $this->input->post('max_mark'),
                'name' => $this->input->post('name'),
            );
            $this->InternalMark_model->add($insert_array);

            $this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Type added</div>');
            redirect('admin/internal_mark/index');
        }
    }

    public function delete($id)
    {
        $this->InternalMark_model->delete($id);
        $this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Type Deleted</div>');
        redirect('admin/internal_mark/index');
    }


    public function edit($id)
    {
        if (!$this->rbac->hasPrivilege('internal_mark_type', 'can_view')) {
            access_denied();
        }
        $this->session->set_userdata('top_menu', 'internal_marks');
        $this->session->set_userdata('sub_menu', 'internal_marks/internal_mark_types');
        $class = $this->class_model->get();
        $data['classlist'] = $class;
        $data['type'] = $this->InternalMark_model->get($id);
        $internalGroup = $this->InternalMark_model->get();
        $data['internalGroup'] = $internalGroup;

        $this->session->set_userdata('top_menu', 'internal_marks');
        $this->session->set_userdata('sub_menu', 'internal_marks/internal_mark_types');

        $this->form_validation->set_rules('type', 'Type', 'trim|required|xss_clean');
        $this->form_validation->set_rules('mark_type', 'Mark Type', 'trim|required|xss_clean');
        $this->form_validation->set_rules('sub_type', 'Sub Type', 'trim|required|xss_clean');
        $this->form_validation->set_rules('class_id', 'Class', 'trim|required|xss_clean');
        $this->form_validation->set_rules('section_id', 'Section', 'trim|required|xss_clean');
        $this->form_validation->set_rules('max_mark', 'Max Mark', 'trim|required|xss_clean');
        $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');


        if ($this->form_validation->run() == FALSE) {
            $this->load->view('layout/header', $data);
            $this->load->view('admin/internal_mark/internal_mark_type_edit', $data);
            $this->load->view('layout/footer', $data);
        } else {
            $insert_array = array(
                'id' => $id,
                'type' => $this->input->post('type'),
                'mark_type' => $this->input->post('mark_type'),
                'sub_type' => $this->input->post('sub_type'),
                'class_id' => $this->input->post('class_id'),
                'section_id' => $this->input->post('section_id'),
                'max_mark' => $this->input->post('max_mark'),
                'name' => $this->input->post('name'),
            );
            $this->InternalMark_model->add($insert_array);

            $this->session->set_flashdata('msg', '<div class="alert alert-success text-center">Type Edited</div>');
            redirect('admin/internal_mark/index');
        }
    }
}
